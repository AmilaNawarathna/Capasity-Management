# Mitra CMS

* Laravel API style'd backend
* API Format to match with google's standards.
* Proper Database Design with required foreign keys and constraints 